package model.world;

public class TrapCell extends Cell {
	int trapDamage;

	public TrapCell() {
		super();
	}

}
