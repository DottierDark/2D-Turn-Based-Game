package model.world;

public class CollectibleCell extends Cell {
	Collectible collectible;

	public CollectibleCell() {
		super();
	}

}
