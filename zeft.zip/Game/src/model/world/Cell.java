package model.world;

public abstract class Cell {
	boolean isVisible;
	public Cell() {
		isVisible = false;
	}

}
