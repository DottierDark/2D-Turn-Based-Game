package model.collectibles;

public enum Collectible {

}
