package engine;

import java.util.ArrayList;

import model.characters.Hero;
import model.characters.Zombie;
import model.world.Cell;

public class Game {
	static ArrayList<Hero> availableHeros;
	static ArrayList<Hero> heros;
	static ArrayList<Zombie> zombies;
	static Cell [][] map;

	public static void loadHeros(String filePath) throws Exception{
		
	}

}
