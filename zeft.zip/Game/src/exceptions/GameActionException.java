package exceptions;

public class GameActionException extends Exception{

	public GameActionException() {
		// TODO Auto-generated constructor stub
	}
	public GameActionException(String s) {
		// TODO Auto-generated constructor stub
	}

}
