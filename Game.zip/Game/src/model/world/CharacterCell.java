package model.world;

public class CharacterCell extends Cell {
Character character;
boolean isSafe;

	public CharacterCell() {
		super();
	}

}
