package exceptions;

public class NoAvailableResourcesException extends GameActionException {

	public NoAvailableResourcesException() {
		// TODO Auto-generated constructor stub
	}
public 	NoAvailableResourcesException(String s){
		
	}
}
