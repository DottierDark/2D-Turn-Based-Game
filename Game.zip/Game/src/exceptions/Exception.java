package exceptions;

public class Exception {



}
